"""
SAP ECC Purchase Order Delivery Day Prediction Model
=====================================================

Business problem:
    Predict how many days late/early an OPEN purchase order schedule line
    will actually be delivered, using patterns learned from CLOSED
    (goods-receipted) purchase order schedule lines.

SAP ECC tables modeled (schedule-line level grain):
    EKKO  - Purchasing Document Header   (EBELN, BSART, LIFNR, EKORG, BEDAT, WAERS)
    EKPO  - Purchasing Document Item     (EBELN, EBELP, MATNR, WERKS, MATKL, NETPR, MEINS, ELIKZ)
    EKET  - Schedule Lines               (EBELN, EBELP, ETENR, EINDT, MENGE, WEMNG)
    EKBE  - PO History (Goods Receipts)  (EBELN, EBELP, VGABE='1', BUDAT, MENGE, BWART)

Grain: one row per EKET schedule line (EBELN + EBELP + ETENR), which is the
level SAP planners actually track delivery performance at.

Target definition:
    actual_delivery_days = (Goods Receipt date [EKBE-BUDAT] - PO creation
                             date [EKKO-BEDAT]) for CLOSED schedule lines
                             (i.e. ELIKZ = 'X' / a matching EKBE GR record exists)

For OPEN schedule lines (no GR yet), we predict actual_delivery_days using a
model trained on the closed population, then derive a predicted GR date and
predicted delay vs. the SAP-planned EINDT.

Output artifacts (written to ./output/):
    ekko_sample.csv, ekpo_sample.csv, eket_sample.csv, ekbe_sample.csv
    training_data_closed_pos.csv
    open_po_predictions.csv
    model_evaluation_report.txt
    feature_importance.csv
    sap_po_delivery_model.joblib
"""

import os
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import OrdinalEncoder
import joblib

RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)

OUT_DIR = os.path.join(os.path.dirname(__file__), "output")
os.makedirs(OUT_DIR, exist_ok=True)


# ---------------------------------------------------------------------------
# 1. SAMPLE DATA GENERATION — mimics SAP ECC MM tables
# ---------------------------------------------------------------------------

def generate_sap_sample_data(n_pos=1500, seed=RANDOM_STATE):
    rng = np.random.default_rng(seed)

    vendors = [f"{100000+i}" for i in range(40)]          # LIFNR
    plants = ["US01", "US02", "DE01", "MY01", "TW01", "SG01"]  # WERKS
    purch_orgs = ["US10", "DE10", "AP10"]                  # EKORG
    material_groups = ["ELEC01", "MECH02", "CHEM03", "PKG04", "RAW05", "TOOL06"]  # MATKL
    doc_types = ["NB", "ZNB", "FO"]                         # BSART (standard PO, custom, framework)
    currencies = ["USD", "EUR", "SGD"]

    # Vendor "true" reliability profile — drives simulated GR timing.
    # (unknown to the model at train time; it must be learned from history)
    vendor_bias_days = rng.normal(0, 4, size=len(vendors))       # avg early(-)/late(+) vs plan
    vendor_variability = rng.uniform(1.5, 8.0, size=len(vendors))  # std dev of lateness
    vendor_profile = {
        v: {"bias": b, "sigma": s}
        for v, b, s in zip(vendors, vendor_bias_days, vendor_variability)
    }

    ekko_rows, ekpo_rows, eket_rows, ekbe_rows = [], [], [], []

    ebeln_counter = 4500000000
    today = datetime(2026, 8, 17)
    start_window = today - timedelta(days=540)  # ~18 months of PO history

    for _ in range(n_pos):
        ebeln = str(ebeln_counter)
        ebeln_counter += 1

        vendor = rng.choice(vendors)
        plant = rng.choice(plants)
        ekorg = rng.choice(purch_orgs)
        bsart = rng.choice(doc_types, p=[0.75, 0.15, 0.10])
        waers = rng.choice(currencies, p=[0.6, 0.3, 0.1])

        bedat = start_window + timedelta(days=int(rng.integers(0, 540)))

        ekko_rows.append({
            "EBELN": ebeln, "BSART": bsart, "LIFNR": vendor,
            "EKORG": ekorg, "BEDAT": bedat.date(), "WAERS": waers,
        })

        n_items = rng.integers(1, 4)  # 1-3 line items per PO
        for ebelp_i in range(1, n_items + 1):
            ebelp = f"{ebelp_i*10:05d}"
            matnr = f"MAT-{rng.integers(1000, 9999)}"
            matkl = rng.choice(material_groups)
            werks = plant
            netpr = round(float(rng.uniform(5, 5000)), 2)
            meins = rng.choice(["EA", "KG", "L", "BOX"])

            # planned lead time varies by material group / doc type (SAP planned delivery time)
            base_lead = {
                "ELEC01": 21, "MECH02": 28, "CHEM03": 35,
                "PKG04": 14, "RAW05": 18, "TOOL06": 25,
            }[matkl]
            if bsart == "FO":
                base_lead += 10  # framework orders tend to plan longer

            n_schedlines = rng.integers(1, 3)  # 1-2 schedule lines per item
            for etenr_i in range(1, n_schedlines + 1):
                etenr = f"{etenr_i:04d}"
                planned_lead = max(3, int(rng.normal(base_lead, 4)))
                eindt = bedat + timedelta(days=planned_lead)  # EKET-EINDT
                menge = round(float(rng.uniform(10, 2000)), 2)

                ekpo_rows.append({
                    "EBELN": ebeln, "EBELP": ebelp, "MATNR": matnr,
                    "MATKL": matkl, "WERKS": werks, "NETPR": netpr,
                    "MEINS": meins,
                })

                eket_rows.append({
                    "EBELN": ebeln, "EBELP": ebelp, "ETENR": etenr,
                    "EINDT": eindt.date(), "MENGE": menge,
                })

                # --- Simulate whether this schedule line has been received (closed) ---
                profile = vendor_profile[vendor]
                actual_delay = rng.normal(profile["bias"], profile["sigma"])
                # Larger orders and chemical/mechanical categories skew slightly later
                if matkl in ("CHEM03", "MECH02"):
                    actual_delay += rng.uniform(0, 3)
                if menge > 1000:
                    actual_delay += rng.uniform(0, 2)
                actual_delay = round(actual_delay)

                simulated_gr_date = eindt + timedelta(days=int(actual_delay))

                # Only "close" (generate a GR / EKBE row) if the simulated GR date
                # has already happened as of "today" -> otherwise it stays OPEN
                if simulated_gr_date <= today:
                    ekbe_rows.append({
                        "EBELN": ebeln, "EBELP": ebelp, "ETENR": etenr,
                        "VGABE": "1", "BWART": "101",
                        "BUDAT": simulated_gr_date.date(),
                        "MENGE": menge,
                    })

    ekko = pd.DataFrame(ekko_rows)
    ekpo = pd.DataFrame(ekpo_rows).drop_duplicates(subset=["EBELN", "EBELP"])
    eket = pd.DataFrame(eket_rows)
    ekbe = pd.DataFrame(ekbe_rows)

    return ekko, ekpo, eket, ekbe


# ---------------------------------------------------------------------------
# 2. FEATURE ENGINEERING at schedule-line grain (EKET)
# ---------------------------------------------------------------------------

def build_schedule_line_dataset(ekko, ekpo, eket, ekbe):
    df = (
        eket
        .merge(ekpo, on=["EBELN", "EBELP"], how="left")
        .merge(ekko, on="EBELN", how="left")
        .merge(ekbe, on=["EBELN", "EBELP", "ETENR"], how="left", suffixes=("", "_GR"))
    )

    df["BEDAT"] = pd.to_datetime(df["BEDAT"])
    df["EINDT"] = pd.to_datetime(df["EINDT"])
    df["BUDAT"] = pd.to_datetime(df["BUDAT"])  # NaT for open lines

    # Planned lead time (SAP norm): days between PO creation and planned schedule date
    df["planned_lead_days"] = (df["EINDT"] - df["BEDAT"]).dt.days

    # Status flag
    df["is_closed"] = df["BUDAT"].notna()

    # Target for closed lines: actual total lead time in days (BEDAT -> BUDAT)
    df["actual_delivery_days"] = (df["BUDAT"] - df["BEDAT"]).dt.days

    # Calendar features from PO creation date (captures seasonality)
    df["po_month"] = df["BEDAT"].dt.month
    df["po_quarter"] = df["BEDAT"].dt.quarter
    df["po_dow"] = df["BEDAT"].dt.dayofweek

    # Order value proxy
    df["line_value"] = df["NETPR"] * df["MENGE"]

    # --- Vendor historical performance features (computed ONLY from closed lines,
    #     leakage-safe: uses each vendor's OTHER closed lines, not itself) ---
    closed = df[df["is_closed"]].copy()
    vendor_stats = (
        closed.groupby("LIFNR")["actual_delivery_days"]
        .agg(vendor_avg_delivery_days="mean", vendor_std_delivery_days="std",
             vendor_history_count="count")
        .reset_index()
    )
    vendor_stats["vendor_std_delivery_days"] = vendor_stats["vendor_std_delivery_days"].fillna(0)

    vendor_delay = closed.copy()
    vendor_delay["delay_vs_plan"] = vendor_delay["actual_delivery_days"] - vendor_delay["planned_lead_days"]
    vendor_delay_stats = (
        vendor_delay.groupby("LIFNR")["delay_vs_plan"]
        .mean().reset_index().rename(columns={"delay_vs_plan": "vendor_avg_delay_vs_plan"})
    )

    matkl_stats = (
        closed.groupby("MATKL")["actual_delivery_days"]
        .mean().reset_index().rename(columns={"actual_delivery_days": "matkl_avg_delivery_days"})
    )

    df = df.merge(vendor_stats, on="LIFNR", how="left")
    df = df.merge(vendor_delay_stats, on="LIFNR", how="left")
    df = df.merge(matkl_stats, on="MATKL", how="left")

    # Fallback for vendors/materials with no history yet -> use global closed mean
    global_mean = closed["actual_delivery_days"].mean()
    for col in ["vendor_avg_delivery_days", "matkl_avg_delivery_days"]:
        df[col] = df[col].fillna(global_mean)
    df["vendor_avg_delay_vs_plan"] = df["vendor_avg_delay_vs_plan"].fillna(0)
    df["vendor_std_delivery_days"] = df["vendor_std_delivery_days"].fillna(closed["actual_delivery_days"].std())
    df["vendor_history_count"] = df["vendor_history_count"].fillna(0)

    return df


FEATURE_COLS = [
    "planned_lead_days", "NETPR", "MENGE", "line_value",
    "po_month", "po_quarter", "po_dow",
    "vendor_avg_delivery_days", "vendor_std_delivery_days", "vendor_history_count",
    "vendor_avg_delay_vs_plan", "matkl_avg_delivery_days",
    "BSART", "EKORG", "WERKS", "MATKL", "MEINS", "WAERS",
]
CATEGORICAL_COLS = ["BSART", "EKORG", "WERKS", "MATKL", "MEINS", "WAERS"]
TARGET_COL = "actual_delivery_days"


# ---------------------------------------------------------------------------
# 3. MODEL TRAINING (on CLOSED schedule lines only)
# ---------------------------------------------------------------------------

def train_model(df):
    closed = df[df["is_closed"]].copy()

    encoder = OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1)
    closed_encoded = closed.copy()
    closed_encoded[CATEGORICAL_COLS] = encoder.fit_transform(closed[CATEGORICAL_COLS])

    X = closed_encoded[FEATURE_COLS]
    y = closed_encoded[TARGET_COL]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_STATE
    )

    candidates = {
        "RandomForest": RandomForestRegressor(
            n_estimators=300, max_depth=8, min_samples_leaf=5,
            random_state=RANDOM_STATE, n_jobs=-1
        ),
        "GradientBoosting": GradientBoostingRegressor(
            n_estimators=300, max_depth=3, learning_rate=0.05,
            random_state=RANDOM_STATE
        ),
    }

    results = {}
    for name, model in candidates.items():
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        results[name] = {
            "model": model,
            "MAE": mean_absolute_error(y_test, preds),
            "RMSE": mean_squared_error(y_test, preds) ** 0.5,
            "R2": r2_score(y_test, preds),
        }

    best_name = min(results, key=lambda k: results[k]["MAE"])
    best_model = results[best_name]["model"]

    return best_name, best_model, encoder, results, (X_test, y_test)


# ---------------------------------------------------------------------------
# 4. PREDICT ON OPEN SCHEDULE LINES
# ---------------------------------------------------------------------------

def predict_open_pos(df, model, encoder, today):
    open_lines = df[~df["is_closed"]].copy()
    if open_lines.empty:
        return open_lines

    open_encoded = open_lines.copy()
    open_encoded[CATEGORICAL_COLS] = encoder.transform(open_lines[CATEGORICAL_COLS])

    X_open = open_encoded[FEATURE_COLS]
    preds = model.predict(X_open)

    open_lines["predicted_delivery_days"] = np.round(preds).astype(int)
    open_lines["predicted_gr_date"] = open_lines["BEDAT"] + pd.to_timedelta(
        open_lines["predicted_delivery_days"], unit="D"
    )
    open_lines["predicted_delay_vs_plan_days"] = (
        open_lines["predicted_delivery_days"] - open_lines["planned_lead_days"]
    )
    open_lines["days_until_predicted_delivery"] = (
        open_lines["predicted_gr_date"] - pd.Timestamp(today)
    ).dt.days
    open_lines["risk_flag"] = np.select(
        [
            open_lines["predicted_delay_vs_plan_days"] > 7,
            open_lines["predicted_delay_vs_plan_days"] > 2,
        ],
        ["HIGH - likely late", "MEDIUM - slight delay risk"],
        default="LOW - on track",
    )
    return open_lines


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

def main():
    today = datetime(2026, 8, 17)

    print("1. Generating sample SAP ECC data (EKKO/EKPO/EKET/EKBE)...")
    ekko, ekpo, eket, ekbe = generate_sap_sample_data(n_pos=1500)
    ekko.to_csv(f"{OUT_DIR}/ekko_sample.csv", index=False)
    ekpo.to_csv(f"{OUT_DIR}/ekpo_sample.csv", index=False)
    eket.to_csv(f"{OUT_DIR}/eket_sample.csv", index=False)
    ekbe.to_csv(f"{OUT_DIR}/ekbe_sample.csv", index=False)
    print(f"   EKKO: {len(ekko)} POs | EKPO: {len(ekpo)} items | "
          f"EKET: {len(eket)} schedule lines | EKBE: {len(ekbe)} GR records")

    print("2. Building schedule-line level feature dataset...")
    df = build_schedule_line_dataset(ekko, ekpo, eket, ekbe)
    n_closed = df["is_closed"].sum()
    n_open = (~df["is_closed"]).sum()
    print(f"   Closed (historical, GR posted): {n_closed} | Open (to predict): {n_open}")

    df[df["is_closed"]].to_csv(f"{OUT_DIR}/training_data_closed_pos.csv", index=False)

    print("3. Training models on closed schedule lines...")
    best_name, best_model, encoder, results, (X_test, y_test) = train_model(df)

    report_lines = ["SAP PO Delivery-Day Prediction — Model Evaluation", "=" * 55, ""]
    for name, r in results.items():
        line = f"{name:>18}:  MAE={r['MAE']:.2f} days | RMSE={r['RMSE']:.2f} days | R2={r['R2']:.3f}"
        print("   " + line)
        report_lines.append(line)
    report_lines.append("")
    report_lines.append(f"Selected best model: {best_name}")

    print("4. Scoring open (in-flight) schedule lines...")
    open_preds = predict_open_pos(df, best_model, encoder, today)

    output_cols = [
        "EBELN", "EBELP", "ETENR", "LIFNR", "WERKS", "MATKL", "BSART",
        "BEDAT", "EINDT", "planned_lead_days",
        "predicted_delivery_days", "predicted_gr_date",
        "predicted_delay_vs_plan_days", "days_until_predicted_delivery", "risk_flag",
    ]
    open_preds[output_cols].sort_values("predicted_delay_vs_plan_days", ascending=False)\
        .to_csv(f"{OUT_DIR}/open_po_predictions.csv", index=False)

    # Feature importance (RandomForest / GradientBoosting both expose this)
    importances = pd.Series(best_model.feature_importances_, index=FEATURE_COLS)
    importances = importances.sort_values(ascending=False)
    importances.to_csv(f"{OUT_DIR}/feature_importance.csv", header=["importance"])

    report_lines.append("")
    report_lines.append("Top feature importances:")
    for feat, val in importances.head(8).items():
        report_lines.append(f"  {feat:>28}: {val:.3f}")

    report_lines.append("")
    report_lines.append(f"Open schedule lines scored: {len(open_preds)}")
    report_lines.append(f"  High risk (>7 days late predicted):   {(open_preds['risk_flag']=='HIGH - likely late').sum()}")
    report_lines.append(f"  Medium risk (2-7 days late predicted): {(open_preds['risk_flag']=='MEDIUM - slight delay risk').sum()}")
    report_lines.append(f"  On track:                              {(open_preds['risk_flag']=='LOW - on track').sum()}")

    with open(f"{OUT_DIR}/model_evaluation_report.txt", "w") as f:
        f.write("\n".join(report_lines))

    joblib.dump({"model": best_model, "encoder": encoder, "features": FEATURE_COLS},
                f"{OUT_DIR}/sap_po_delivery_model.joblib")

    print("\nDone. Outputs written to:", OUT_DIR)
    print("\n".join(report_lines))


if __name__ == "__main__":
    main()
