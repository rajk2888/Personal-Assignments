# Browser setup guide - app.powerbi.com (Mac, no Desktop)

Rebuilds **HR Analytics Dashboard.twbx** as a Power BI semantic model + 3-page report using only the browser.
Time: about 60-90 minutes. Files used: `Data.xlsx`, `Measures.md`. Check your numbers against the **Check Table** sheet in `Migration-Report.xlsx`.

> Menu labels in the Power BI service change from time to time. If a label below differs slightly, look for the closest match - the steps stay the same.

## 0. Before you start
- You need a Power BI Pro / Premium Per User licence (or a Fabric capacity workspace) to edit models in the browser.
- **Editing data models in the service** must be allowed. If you can't find **Open data model** in step 2, ask your Power BI admin to enable *Users can edit data models in the Power BI service* (tenant setting); in a shared workspace also check **Workspace settings → General → Data model settings**.
- **Map visual:** the map on the Overview page needs *Map and filled map visuals* (or *Azure Maps*) enabled by your admin. If it is off, skip that visual; everything else still works.

## 1. Upload Data.xlsx → semantic model
1. Go to **app.powerbi.com** → **My workspace** (or a workspace you own).
2. Select **+ New item** → **Semantic model** → **Excel** (some tenants show **Upload → Browse**).
3. Choose **Browse this device** and pick `Data.xlsx`.
4. If a navigator/preview appears, tick the **13 tables** (table icon, not the sheet icon): `Employees, Stores, MonthlyPerformance, RoleKPIs, BusinessOutcomes, Calendar, CategoryBridge, EmployeeMetricPicker, PerformanceMetricPicker, OtherMetricPicker, CustomerMetricPicker, SalesMetricPicker, RankBand` → **Create / Load**.
5. Wait until the semantic model **HR Analytics** (or *Data*) appears in the workspace. Rename it *HR Analytics* (… → Settings).

A locally uploaded file can't be refreshed on a schedule. That's fine for testing. For refresh, put Data.xlsx on OneDrive for work/SharePoint and import it from there instead.

## 2. Open the data model and check types
1. Open the semantic model → **Open data model** (top ribbon). The model view opens in edit mode.
2. In the **Data** pane check these column types (select column → **Column tools → Data type**):
   - Date: `Employees[Hire Date]`, `Employees[Exit Date]`, `Stores[Opening Date]`, `MonthlyPerformance[Month]`, `RoleKPIs[Month]`, `BusinessOutcomes[Month]`, `Calendar[Month Start]`
   - True/False: `MonthlyPerformance[Promotion Flag]`, `MonthlyPerformance[Salary Increase Flag]`, `CategoryBridge[Show On Overview]`
   - Whole number: `Employees[Age]`, `Calendar[Year]`, `Calendar[Month Number]`, all `Sort Order` / `Type Order` columns
3. **Sort by column** (select column → Column tools → Sort by column):
   - `Calendar[Year Month]` by `Month Start`; `Calendar[Month Name]` by `Month Number`
   - `CategoryBridge[Category Type]` by `Type Order`
   - `Metric` in each of the five *…MetricPicker* tables by `Sort Order`; `RankBand[Band]` by `Sort Order`
4. **Summarization:** set *Don't summarize* on `Calendar[Year]`, `Employees[Age]`, and every latitude/longitude column. Set **Data category** *Latitude* / *Longitude* on `Employees[Store Location Latitude]` / `[Store Location Longitude]` and *City* on `Employees[Store Location]`.
5. Optional tidy-up: hide `Employees[Manager Name (Source)]` and the `Sort Order` / `Type Order` columns.

## 3. Relationships (Manage relationships → New)
Create exactly these 8. "Many" side first. All are **Many-to-one**, **Single** cross-filter direction and **active**, except the last one.

| # | From (many) | To (one) | Cross-filter |
|---|---|---|---|
| 1 | `MonthlyPerformance[Employee ID]` | `Employees[Employee ID]` | Single |
| 2 | `RoleKPIs[Employee ID]` | `Employees[Employee ID]` | Single |
| 3 | `Employees[Store ID]` | `Stores[Store ID]` | Single |
| 4 | `BusinessOutcomes[Store ID]` | `Stores[Store ID]` | Single |
| 5 | `MonthlyPerformance[Month]` | `Calendar[Month Start]` | Single |
| 6 | `RoleKPIs[Month]` | `Calendar[Month Start]` | Single |
| 7 | `BusinessOutcomes[Month]` | `Calendar[Month Start]` | Single |
| 8 | `CategoryBridge[Employee ID]` | `Employees[Employee ID]` | **Both** |

The five *…MetricPicker* tables and `RankBand` stay **disconnected** (no relationships). Delete any relationship the service auto-detected that is not in this list.

Why #8 is "Both": `CategoryBridge` is the Tableau *Select Category* parameter turned into data (one row per employee × category type). Picking "Job Role" in a slicer and putting `Category Value` on an axis must filter Employees, then the fact tables.

## 4. Measures
Open `Measures.md` and create all 40 measures **in order**, each in the home table shown, with the format shown. Tip: after each section, drop the first measure into a card on a scratch page to confirm it isn't an error.

## 5. Build the report
1. Back in the workspace: semantic model → **Create report → Start from scratch** (or **Explore → Create a blank report**).
2. Click **Edit**. In **Format** (page) → **Canvas settings** → Type *Custom*, **1300 × 800**. Do this on each page.
3. Rename *Page 1* to **Overview**, then add pages **Performance** and **Business Sales**.
4. For each visual below: click the visual type in the **Build** (Visualizations) pane, drag fields into the wells shown, then size/position it roughly as given (x, y, width, height in pixels; Format → General → Properties → Size and position).
5. Slicer settings live in **Format → Slicer settings** (Style = *Dropdown* or *Between*, **Single select** on/off).

### 5.1 Page "Overview"  (Tableau: Overview Dashboard)

| # | Visual | Type | Fields (well → field) | Position x,y,w,h | Settings / notes |
|---|---|---|---|---|---|
| 1 | Hire Date | Slicer | Field → Employees[Hire Date] | 18,150,172,90 | Style **Between**; Tableau: Hire Date range filter (2012-01-04 to 2022-01-01 = full range). |
| 2 | Select Category | Slicer | Field → CategoryBridge[Category Type] | 18,250,172,64 | Style **Dropdown**; **Single select ON**; select **Job Role** before saving; Filters pane → this visual → Category Type: tick only Job Role, Job Level, Department, Age Group, Education Level; Replaces parameter "Dim Parameter1". Single select, default Job Role. Visual-level filter on this slicer: Category Type is not "Full Name". |
| 3 | Manager Name | Slicer | Field → Employees[Manager Name] | 18,324,172,64 | Style **Dropdown**; Tableau: Manager_Name (calc) multi-select dropdown. |
| 4 | Total Employees | Card | Fields → measure **Total Employees** | 212,141,200,58 | Tableau: Emp KPI |
| 5 | Current Workforce | Card | Fields → measure **Current Workforce** | 212,203,200,58 | Tableau: Emp KPI 2 |
| 6 | Former Workforce | Card | Fields → measure **Former Workforce** | 212,265,200,58 | Tableau: Emp KPI 2 |
| 7 | Turnover Rate % | Card | Fields → measure **Turnover Rate %** | 212,327,200,58 | Tableau: Emp KPI 2 |
| 8 | Avg Base Salary | Card | Fields → measure **Avg Base Salary** | 448,141,200,58 | Callout value → Display units **Thousands**; Tableau: Avg Salary KPI ($#,##0.00K) - display units Thousands |
| 9 | Avg Monthly Bonus | Card | Fields → measure **Avg Monthly Bonus** | 448,203,200,58 | Tableau: Salary KPI 2 |
| 10 | Avg Benefits Cost | Card | Fields → measure **Avg Benefits Cost** | 448,265,200,58 | Tableau: Salary KPI 2 |
| 11 | Salary Increases | Card | Fields → measure **Salary Increases** | 448,327,200,58 | Tableau: Salary KPI 2 |
| 12 | Store Location | Map (or Azure map) | Location → Employees[Store Location]<br>Latitude → Employees[Store Location Latitude] (set to **Average**)<br>Longitude → Employees[Store Location Longitude] (set to **Average**)<br>Bubble size → measure **Total Employees**<br>Tooltips → measure **Current Workforce**, measure **Former Workforce** | 685,138,574,249 | Decision Q3: latitude AND longitude both from the employee Store Location (Tableau mixed in store City longitude). Set Latitude/Longitude to Average. |
| 13 | Workforce by Category (Top 10) | Clustered bar chart | Y-axis → CategoryBridge[Category Value]<br>X-axis → measure **Current Workforce (Top 10)**, measure **Former Workforce (Top 10)** | 211,408,400,356 | Sort (… → Sort axis) by **Former Workforce (Top 10)**, descending; Tableau: Categories. Decision Q1: Top 10 categories by Former Workforce (the Top-10 logic is inside the two measures). Sort by Former Workforce (Top 10), descending. |
| 14 | Workforce by Store Type | 100% stacked bar chart | Y-axis → Stores[Store Type]<br>X-axis → measure **Current Workforce**, measure **Former Workforce**<br>Tooltips → measure **Total Employees** | 628,410,190,356 | Tableau: Store Type donuts (Percent-of-Total). Rewritten as a 100% stacked bar: same Current vs Former split per store type. |
| 15 | Top Employees | Table | Columns → Employees[Employee Name], Employees[Manager Name], measure **Top Employee Score** | 833,407,428,356 | Sort (… → Sort axis) by **Top Employee Score**, descending; Tableau: Top Employees (Top 11 by score, Matthew Allen hidden = 10 rows). Logic is inside Top Employee Score. Sort by it, descending. |

**Edit interactions** (select the slicer → Format ribbon → *Edit interactions* → click the ⦸ "None" icon on the target):
- *Hire Date* slicer → *Top Employees*: **None**
- *Manager Name* slicer → *Top Employees*: **None**

### 5.2 Page "Performance"  (Tableau: Performance Dashboard)

| # | Visual | Type | Fields (well → field) | Position x,y,w,h | Settings / notes |
|---|---|---|---|---|---|
| 1 | Year-Month | Slicer | Field → Calendar[Month Start] | 18,150,172,90 | Style **Between**; Tableau: Year_Month range filter (2022-01 to 2024-12 = full range). |
| 2 | Select Category | Slicer | Field → CategoryBridge[Category Type] | 18,250,172,64 | Style **Dropdown**; **Single select ON**; select **Full Name** before saving; Replaces parameter "Dim Parameter2". Single select, default Full Name. |
| 3 | Workforce Status | Slicer | Field → Employees[Workforce Status] | 18,324,172,64 | Style **Dropdown**; select **Current Workforce** before saving; Tableau: Workforce_Status dropdown, default Current Workforce. |
| 4 | Employee Metrics | Slicer | Field → EmployeeMetricPicker[Metric] | 207,145,247,56 | Style **Dropdown**; **Single select ON**; Replaces parameter "Employee Metrics". Single select; nothing selected = Tableau default. |
| 5 | Employee Metrics (Top 10) | Clustered bar chart | Y-axis → CategoryBridge[Category Value]<br>X-axis → measure **Employee Metric (Top 10)** | 207,205,247,262 | Sort (… → Sort axis) by **Employee Metric (Top 10)**, descending; Data labels ON; Tableau: Employee Metrics. Top 10 by the selected metric is inside the measure (Rank_Measure INDEX() <= 10). Sort descending. |
| 6 | Performance Metrics | Slicer | Field → PerformanceMetricPicker[Metric] | 476,145,247,56 | Style **Dropdown**; **Single select ON**; Replaces parameter "Performance Metrics". Single select; nothing selected = Tableau default. |
| 7 | Performance Metrics (Top 10) | Clustered bar chart | Y-axis → CategoryBridge[Category Value]<br>X-axis → measure **Performance Metric (Top 10)** | 476,205,247,262 | Sort (… → Sort axis) by **Performance Metric (Top 10)**, descending; Data labels ON; Tableau: Performance Metrics. Top 10 by the selected metric is inside the measure (Rank_Measure INDEX() <= 10). Sort descending. |
| 8 | Customer Metrics | Slicer | Field → CustomerMetricPicker[Metric] | 745,145,247,56 | Style **Dropdown**; **Single select ON**; Replaces parameter "Customer Metrics". Single select; nothing selected = Tableau default. |
| 9 | Customer Metrics (Top 10) | Clustered bar chart | Y-axis → CategoryBridge[Category Value]<br>X-axis → measure **Customer Metric (Top 10)** | 745,205,247,262 | Sort (… → Sort axis) by **Customer Metric (Top 10)**, descending; Data labels ON; Tableau: Customer Metrics. Top 10 by the selected metric is inside the measure (Rank_Measure INDEX() <= 10). Sort descending. |
| 10 | Other Metrics | Slicer | Field → OtherMetricPicker[Metric] | 1014,145,247,56 | Style **Dropdown**; **Single select ON**; Replaces parameter "Other Metrics". Single select; nothing selected = Tableau default. |
| 11 | Other Metrics (Top 10) | Clustered bar chart | Y-axis → CategoryBridge[Category Value]<br>X-axis → measure **Other Metric (Top 10)** | 1014,205,247,262 | Sort (… → Sort axis) by **Other Metric (Top 10)**, descending; Data labels ON; Tableau: Other Metrics. Top 10 by the selected metric is inside the measure (Rank_Measure INDEX() <= 10). Sort descending. |
| 12 | Monthly Performance Rating | Area chart | X-axis → Calendar[Month Start]<br>Y-axis → measure **Avg Performance Rating** | 209,491,510,271 | Tableau: Monthly Performance Rating (area + line). Year-Month slicer does NOT filter it (matches Tableau). |
| 13 | Training Hours vs Performance Rating | Scatter chart | Values (details) → Employees[Employee ID]<br>X-axis → measure **Avg Training Hours**<br>Y-axis → measure **Avg Performance Rating** | 747,489,249,274 | Tableau: Training_Performance Rating. One dot per employee. |
| 14 | Age vs Performance Rating | Scatter chart | Values (details) → Employees[Employee ID]<br>X-axis → measure **Avg Age**<br>Y-axis → measure **Avg Performance Rating** | 1014,489,249,274 | Tableau: Employees_Age Relationship. One dot per employee. |

**Edit interactions** (select the slicer → Format ribbon → *Edit interactions* → click the ⦸ "None" icon on the target):
- *Year-Month* slicer → *Monthly Performance Rating*: **None**

### 5.3 Page "Business Sales"  (Tableau: Business Sales Dashboard)

| # | Visual | Type | Fields (well → field) | Position x,y,w,h | Settings / notes |
|---|---|---|---|---|---|
| 1 | Year | Slicer | Field → Calendar[Year] | 18,150,172,64 | Style **Dropdown**; Tableau: YEAR(Year_Month) multi-select dropdown. |
| 2 | Select Metrics | Slicer | Field → SalesMetricPicker[Metric] | 18,224,172,64 | Style **Dropdown**; **Single select ON**; Replaces parameter "Sales Metrics". Single select; nothing selected = Customer Satisfaction. |
| 3 | Sales Rank | Slicer | Field → RankBand[Band] | 18,298,172,64 | Style **Dropdown**; **Single select ON**; Decision Q2: working Top 5 / Bottom 5 switch. Nothing selected = Top 5. |
| 4 | Sales Actual | Card | Fields → measure **Sales Actual** | 214,143,202,126 | Callout value → Display units **Billions**, 3 decimals; Tableau: Sales Actual KPI ($0.000B) - display units Billions, 3 decimals |
| 5 | Sales Target | Card | Fields → measure **Sales Target** | 450,143,202,126 | Callout value → Display units **Billions**, 3 decimals; Tableau: Sales Target KPI |
| 6 | Sales Variance % | Card | Fields → measure **Sales Variance %** | 214,288,202,126 | Tableau: Sales Variance KPI |
| 7 | Avg Customer Satisfaction | Card | Fields → measure **Avg Customer Satisfaction** | 450,288,202,126 | Tableau: CSC KPI |
| 8 | Sales Over Time | Area chart | X-axis → Calendar[Month Start]<br>Y-axis → measure **Sales Actual** | 679,139,584,269 | Tableau: Sales Over Time. Year slicer does NOT filter it (matches Tableau). |
| 9 | Store Sales (Top/Bottom 5) | Clustered bar chart | Y-axis → Stores[Store Name]<br>X-axis → measure **Sales Actual (Selected Band)** | 203,430,400,336 | Sort (… → Sort axis) by **Sales Actual (Selected Band)**, descending; Data labels ON; Tableau: Top Stores, Sales pane. |
| 10 | Selected Metric by Store | Clustered bar chart | Y-axis → Stores[Store Name]<br>X-axis → measure **Sales Metric (Selected Band)** | 608,430,245,336 | Sort (… → Sort axis) by **Sales Actual (Selected Band)**, descending; Data labels ON; Tableau: Top Stores, Metrics_Sales pane (Tableau shows both panes in one chart; Power BI cannot share one axis between $ millions and a 0-10 score). |
| 11 | Sales vs Target by Department | Clustered bar chart | Y-axis → BusinessOutcomes[Department]<br>X-axis → measure **Sales Actual**, measure **Sales Target**<br>Tooltips → measure **Sales Variance %** | 871,432,392,336 | Tableau: Department donuts (Actual vs Target, centre = Sales Variance %). Rewritten as clustered bar; Variance % in tooltip. |

**Edit interactions** (select the slicer → Format ribbon → *Edit interactions* → click the ⦸ "None" icon on the target):
- *Year* slicer → *Sales Over Time*: **None**

## 6. Things that work differently from Tableau
- **Parameters → slicers.** The five metric pickers are tiny disconnected tables. Selecting nothing = the Tableau default value. The two *Select Category* parameters use `CategoryBridge`. Always keep exactly one Category Type selected.
- **Top 10 / Top 5 logic is inside the measures** (`… (Top 10)`, `Top Employee Score`, `… (Selected Band)`), so you don't need Top N filters. Rows outside the top N return blank and Power BI hides them.
- **Ties.** If two categories tie on the 10th value, Power BI shows both (Tableau's INDEX() shows one, picked arbitrarily). This is most likely with *Full Name* on the Performance page.
- **Slow Top-10 visual?** The Performance page ranks about 6,000 names per visual. If a chart takes more than a few seconds, swap its `… (Top 10)` measure for the plain metric measure (for example `Employee Metric`) and add a visual-level filter on `Category Value`: **Top N → Top 10 → by value = that metric**. The result is the same.
- **Donuts per category** (Store Type, Department) are bar charts, because Power BI can't repeat one donut per category.
- **Navigation / export / show-hide buttons:** use the page tabs, **Export → PDF/PowerPoint** in the service, and keep the help text visible. Bookmark toggles can be added later in Desktop.
- **Background images** (dash1-3.png) were left out. Re-add one via Format → Canvas background if you want the Tableau look.

## 7. Verify (must match Tableau)
Put these on a scratch page as cards (no slicers) and compare with `Migration-Report.xlsx → Check Table` (column C = Tableau, column D = what Data.xlsx produces):

| Measure | Expected |
|---|---|
| Total Employees | 7,500 |
| Current Workforce / Former Workforce | 6,009 / 1,491 |
| Turnover Rate % | 19.88% |
| Avg Base Salary | $27,253.86 |
| Avg Monthly Bonus / Avg Benefits Cost | $248.60 / $748.92 |
| Salary Increases | 3,209 |
| Sales Actual / Sales Target | $1,979,526,902 / $1,978,381,860 |
| Sales Variance % | 0.06% |
| Avg Customer Satisfaction | 7.5 |
| Row counts (table visual with a COUNTROWS card per table) | 7,500 · 150 · 236,591 · 236,591 · 16,200 |

Default Top lists to spot-check: Top 10 Job Roles by Former Workforce start with **Cashier 318, Sales Associate 187, Stock Clerk 173**. Top Employees starts with **William Moon IV 4.89** and has no "Matthew Allen". Top 5 stores start with **New York Superstore #81**.

## 8. Hand-off to Windows
Give the Windows user the whole `Tableau-to-PowerBI` folder. `PowerBI-Project/README.md` explains how to open `HR Analytics.pbip` in Power BI Desktop. It is the same model (same tables, relationships and measures) with the three pages pre-built.
