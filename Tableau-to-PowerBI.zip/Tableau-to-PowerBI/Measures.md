# DAX measures - HR Analytics (Tableau → Power BI)

40 measures. Create them **in the order listed** (later measures call earlier ones).

**How to paste in app.powerbi.com:** open the semantic model → **Open data model** → in the **Data** pane click the *home table* shown below → **New measure** → replace everything in the formula bar with the code block → press Enter (✓) → in **Measure tools** set the format shown.

Table names have no spaces on purpose (they are the Excel table names in Data.xlsx), so no quotes are needed.

## Home table: `Employees`

### 1. Total Employees
- Format: Whole number, thousands separator  (`#,0`)
- Display folder: Workforce
- Replaces Tableau: `COUNT(employees)`

```dax
Total Employees =
COUNTROWS ( Employees )
```

### 2. Current Workforce
- Format: Whole number, thousands separator  (`#,0`)
- Display folder: Workforce
- Replaces Tableau: `count(if isnull([Exit_Date]) then [Employee_Id] end)`

```dax
Current Workforce =
CALCULATE ( COUNTROWS ( Employees ), KEEPFILTERS ( Employees[Workforce Status] = "Current Workforce" ) )
```

### 3. Former Workforce
- Format: Whole number, thousands separator  (`#,0`)
- Display folder: Workforce
- Replaces Tableau: `count(if NOT isnull([Exit_Date]) then [Employee_Id] end)`

```dax
Former Workforce =
CALCULATE ( COUNTROWS ( Employees ), KEEPFILTERS ( Employees[Workforce Status] = "Former Workforce" ) )
```

### 4. Turnover Rate %
- Format: Percentage, 2 decimals  (`0.00%`)
- Display folder: Workforce
- Replaces Tableau: `[Former Workforce]/COUNT(employees)`

```dax
Turnover Rate % =
DIVIDE ( [Former Workforce], [Total Employees] )
```

### 5. Current Workforce %
- Format: Percentage, 1 decimal  (`0.0%`)
- Display folder: Workforce
- Replaces Tableau: `Percent of Total quick table calc (Store Type)`

```dax
Current Workforce % =
DIVIDE ( [Current Workforce], [Total Employees] )
```

### 6. Former Workforce %
- Format: Percentage, 1 decimal  (`0.0%`)
- Display folder: Workforce
- Replaces Tableau: `Percent of Total quick table calc (Store Type)`

```dax
Former Workforce % =
DIVIDE ( [Former Workforce], [Total Employees] )
```

### 7. Avg Base Salary
- Format: Currency ($), 2 decimals  (`\$#,0.00`)
- Display folder: Compensation
- Replaces Tableau: `AVG([Base_Salary_Annual])`

```dax
Avg Base Salary =
AVERAGE ( Employees[Base Salary Annual] )
```

### 8. Avg Age
- Format: Whole number, thousands separator  (`#,0`)
- Display folder: Workforce
- Replaces Tableau: `AVG([Age])`

```dax
Avg Age =
AVERAGE ( Employees[Age] )
```

### 9. Overview Category Rank
- Format: Whole number  (`0`)
- Display folder: Ranking
- Replaces Tableau: `Rank_Measure = INDEX() (Categories)`

```dax
Overview Category Rank =
VAR _type = IF ( HASONEVALUE ( CategoryBridge[Category Type] ), VALUES ( CategoryBridge[Category Type] ), "Job Role" )
RETURN
    IF (
        HASONEVALUE ( CategoryBridge[Category Value] ),
        CALCULATE (
            RANKX ( ALLSELECTED ( CategoryBridge[Category Value] ), [Former Workforce], , DESC, Skip ),
            CategoryBridge[Category Type] = _type
        )
    )
```

### 10. Current Workforce (Top 10)
- Format: Whole number, thousands separator  (`#,0`)
- Display folder: Ranking
- Replaces Tableau: `Categories: Current Workforce with Rank_Measure <= 10`

```dax
Current Workforce (Top 10) =
VAR _type = IF ( HASONEVALUE ( CategoryBridge[Category Type] ), VALUES ( CategoryBridge[Category Type] ), "Job Role" )
VAR _value = CALCULATE ( [Current Workforce], CategoryBridge[Category Type] = _type )
VAR _rank =
    CALCULATE (
        RANKX ( ALLSELECTED ( CategoryBridge[Category Value] ), [Former Workforce], , DESC, Skip ),
        CategoryBridge[Category Type] = _type
    )
RETURN
    IF ( NOT ISBLANK ( CALCULATE ( [Former Workforce], CategoryBridge[Category Type] = _type ) ) && _rank <= 10, _value )
```

### 11. Former Workforce (Top 10)
- Format: Whole number, thousands separator  (`#,0`)
- Display folder: Ranking
- Replaces Tableau: `Categories: Former Workforce with Rank_Measure <= 10`

```dax
Former Workforce (Top 10) =
VAR _type = IF ( HASONEVALUE ( CategoryBridge[Category Type] ), VALUES ( CategoryBridge[Category Type] ), "Job Role" )
VAR _value = CALCULATE ( [Former Workforce], CategoryBridge[Category Type] = _type )
VAR _rank =
    CALCULATE (
        RANKX ( ALLSELECTED ( CategoryBridge[Category Value] ), [Former Workforce], , DESC, Skip ),
        CategoryBridge[Category Type] = _type
    )
RETURN
    IF ( NOT ISBLANK ( _value ) && _rank <= 10, _value )
```

## Home table: `MonthlyPerformance`

### 12. Avg Performance Rating
- Format: Decimal, 2 places  (`0.00`)
- Display folder: Performance
- Replaces Tableau: `AVG([Performance_Rating])`

```dax
Avg Performance Rating =
AVERAGE ( MonthlyPerformance[Performance Rating] )
```

### 13. Overall Performance Score
- Format: Decimal, 2 places  (`0.00`)
- Display folder: Performance
- Replaces Tableau: `AVG([Performance Rating (copy)])`

```dax
Overall Performance Score =
AVERAGE ( MonthlyPerformance[Performance Rating] )
```

### 14. Avg Training Hours
- Format: Decimal, 1 place  (`#,0.0`)
- Display folder: Performance
- Replaces Tableau: `AVG([Training_Hours])`

```dax
Avg Training Hours =
AVERAGE ( MonthlyPerformance[Training Hours] )
```

### 15. Avg Monthly Bonus
- Format: Currency ($), 2 decimals  (`\$#,0.00`)
- Display folder: Compensation
- Replaces Tableau: `AVG([Monthly_Bonus])`

```dax
Avg Monthly Bonus =
AVERAGE ( MonthlyPerformance[Monthly Bonus] )
```

### 16. Avg Benefits Cost
- Format: Currency ($), 2 decimals  (`\$#,0.00`)
- Display folder: Compensation
- Replaces Tableau: `AVG([Benefits_Cost])`

```dax
Avg Benefits Cost =
AVERAGE ( MonthlyPerformance[Benefits Cost] )
```

### 17. Salary Increases
- Format: Whole number, thousands separator  (`#,0`)
- Display folder: Compensation
- Replaces Tableau: `SUM([Salary Increase])`

```dax
Salary Increases =
CALCULATE ( COUNTROWS ( MonthlyPerformance ), MonthlyPerformance[Salary Increase Flag] = TRUE () )
```

### 18. Top Employee Score
- Format: Decimal, 2 places  (`0.00`)
- Display folder: Ranking
- Replaces Tableau: `Top 11 Full_Name by AVG(Overall Performance Score), "Matthew Allen" hidden`

```dax
Top Employee Score =
VAR _rank =
    RANKX (
        ALLSELECTED ( Employees[Employee Name] ),
        CALCULATE ( [Overall Performance Score], REMOVEFILTERS ( Employees[Manager Name] ) ),
        ,
        DESC,
        Skip
    )
RETURN
    IF (
        HASONEVALUE ( Employees[Employee Name] )
            && _rank <= 11
            && SELECTEDVALUE ( Employees[Employee Name] ) <> "Matthew Allen",
        [Overall Performance Score]
    )
```

## Home table: `RoleKPIs`

### 19. Employee Turnover % (KPI)
- Format: Decimal, 2 places  (`0.00`)
- Display folder: Role KPIs
- Replaces Tableau: `if [Kpi_2_Name] = "Employee Turnover %" then [Kpi_2_Value] END`

```dax
Employee Turnover % (KPI) =
CALCULATE ( AVERAGE ( RoleKPIs[KPI 2 Value] ), RoleKPIs[KPI 2 Name] = "Employee Turnover %" )
```

### 20. Efficiency Rating
- Format: Decimal, 2 places  (`0.00`)
- Display folder: Role KPIs
- Replaces Tableau: `if [Kpi_3_Name] = "Efficiency Rating" then [Kpi_3_Value] END`

```dax
Efficiency Rating =
CALCULATE ( AVERAGE ( RoleKPIs[KPI 3 Value] ), RoleKPIs[KPI 3 Name] = "Efficiency Rating" )
```

### 21. Customer Complaints
- Format: Decimal, 2 places  (`0.00`)
- Display folder: Role KPIs
- Replaces Tableau: `if [Kpi_3_Name] = "Customer Complaints" then [Kpi_3_Value] END`

```dax
Customer Complaints =
CALCULATE ( AVERAGE ( RoleKPIs[KPI 3 Value] ), RoleKPIs[KPI 3 Name] = "Customer Complaints" )
```

### 22. Customer Rating
- Format: Decimal, 2 places  (`0.00`)
- Display folder: Role KPIs
- Replaces Tableau: `if [Kpi_3_Name] = "Customer Rating" then [Kpi_3_Value] END`

```dax
Customer Rating =
CALCULATE ( AVERAGE ( RoleKPIs[KPI 3 Value] ), RoleKPIs[KPI 3 Name] = "Customer Rating" )
```

### 23. Customer Satisfaction (KPI)
- Format: Decimal, 2 places  (`0.00`)
- Display folder: Role KPIs
- Replaces Tableau: `if [Kpi_3_Name] = "Customer Satisfaction" then [Kpi_3_Value] END`

```dax
Customer Satisfaction (KPI) =
CALCULATE ( AVERAGE ( RoleKPIs[KPI 3 Value] ), RoleKPIs[KPI 3 Name] = "Customer Satisfaction" )
```

### 24. Avg Productivity Index
- Format: Decimal, 3 places  (`0.000`)
- Display folder: Role KPIs
- Replaces Tableau: `AVG([Productivity_Index])`

```dax
Avg Productivity Index =
AVERAGE ( RoleKPIs[Productivity Index] )
```

## Home table: `BusinessOutcomes`

### 25. Sales Actual
- Format: Currency ($), 0 decimals  (`\$#,0`)
- Display folder: Sales
- Replaces Tableau: `SUM([Sales_Actual])`

```dax
Sales Actual =
SUM ( BusinessOutcomes[Sales Actual] )
```

### 26. Sales Target
- Format: Currency ($), 0 decimals  (`\$#,0`)
- Display folder: Sales
- Replaces Tableau: `SUM([Sales_Target])`

```dax
Sales Target =
SUM ( BusinessOutcomes[Sales Target] )
```

### 27. Sales Variance %
- Format: Percentage, 2 decimals  (`0.00%`)
- Display folder: Sales
- Replaces Tableau: `(SUM([Sales_Actual]) - SUM([Sales_Target]))/SUM([Sales_Target])`

```dax
Sales Variance % =
DIVIDE ( [Sales Actual] - [Sales Target], [Sales Target] )
```

### 28. Avg Customer Satisfaction
- Format: Decimal, 1 place  (`0.0`)
- Display folder: Sales
- Replaces Tableau: `AVG([Customer_Satisfaction])`

```dax
Avg Customer Satisfaction =
AVERAGE ( BusinessOutcomes[Customer Satisfaction] )
```

### 29. Store Rank Band
- Format: Text (no format)
- Display folder: Ranking
- Replaces Tableau: `Rank_filter (RANK of SUM(Sales_Actual), Top 5 / Bottom 5)`

```dax
Store Rank Band =
VAR _rankDesc = RANKX ( ALLSELECTED ( Stores[Store Name] ), [Sales Actual], , DESC, Skip )
VAR _rankAsc = RANKX ( ALLSELECTED ( Stores[Store Name] ), [Sales Actual], , ASC, Skip )
RETURN
    IF (
        HASONEVALUE ( Stores[Store Name] ),
        IF ( _rankDesc <= 5, "Top 5", IF ( _rankAsc <= 5, "Bottom 5", "Other" ) )
    )
```

## Home table: `EmployeeMetricPicker`

### 30. Employee Metric
- Format: Decimal, 2 places  (`#,0.00`)
- Display folder: Metric switch
- Replaces Tableau: `Metrics_Employee (CASE on Employee Metrics parameter)`

```dax
Employee Metric =
SWITCH (
    SELECTEDVALUE ( EmployeeMetricPicker[Metric], "Employee Satisfaction" ),
    "Employee Satisfaction", AVERAGE ( MonthlyPerformance[Employee Satisfaction] ),
    "Engagement Index", AVERAGE ( MonthlyPerformance[Engagement Index] ),
    "Employee Turnover %", [Employee Turnover % (KPI)],
    "Base Salary Annual", [Avg Base Salary]
)
```

### 31. Employee Metric (Top 10)
- Format: Decimal, 2 places  (`#,0.00`)
- Display folder: Metric switch
- Replaces Tableau: `Metrics_Employee filtered by Rank_Measure <= 10`

```dax
Employee Metric (Top 10) =
VAR _type = IF ( HASONEVALUE ( CategoryBridge[Category Type] ), VALUES ( CategoryBridge[Category Type] ), "Full Name" )
VAR _value = CALCULATE ( [Employee Metric], CategoryBridge[Category Type] = _type )
VAR _rank =
    CALCULATE (
        RANKX ( ALLSELECTED ( CategoryBridge[Category Value] ), [Employee Metric], , DESC, Skip ),
        CategoryBridge[Category Type] = _type
    )
RETURN
    IF ( NOT ISBLANK ( _value ) && _rank <= 10, _value )
```

## Home table: `PerformanceMetricPicker`

### 32. Performance Metric
- Format: Decimal, 2 places  (`#,0.00`)
- Display folder: Metric switch
- Replaces Tableau: `Metrics_Peformance (CASE on Performance Metrics parameter)`

```dax
Performance Metric =
SWITCH (
    SELECTEDVALUE ( PerformanceMetricPicker[Metric], "Performance Rating" ),
    "Performance Rating", [Avg Performance Rating],
    "Productivity Index", [Avg Productivity Index],
    "Efficiency Rating", [Efficiency Rating]
)
```

### 33. Performance Metric (Top 10)
- Format: Decimal, 2 places  (`#,0.00`)
- Display folder: Metric switch
- Replaces Tableau: `Metrics_Peformance filtered by Rank_Measure <= 10`

```dax
Performance Metric (Top 10) =
VAR _type = IF ( HASONEVALUE ( CategoryBridge[Category Type] ), VALUES ( CategoryBridge[Category Type] ), "Full Name" )
VAR _value = CALCULATE ( [Performance Metric], CategoryBridge[Category Type] = _type )
VAR _rank =
    CALCULATE (
        RANKX ( ALLSELECTED ( CategoryBridge[Category Value] ), [Performance Metric], , DESC, Skip ),
        CategoryBridge[Category Type] = _type
    )
RETURN
    IF ( NOT ISBLANK ( _value ) && _rank <= 10, _value )
```

## Home table: `OtherMetricPicker`

### 34. Other Metric
- Format: Decimal, 1 place  (`#,0.0`)
- Display folder: Metric switch
- Replaces Tableau: `Metrics_Other (CASE on Other Metrics parameter)`

```dax
Other Metric =
SWITCH (
    SELECTEDVALUE ( OtherMetricPicker[Metric], "Training Hours" ),
    "Training Hours", [Avg Training Hours],
    "Overtime Hours", AVERAGE ( MonthlyPerformance[Overtime Hours] ),
    "Monthly Bonus", [Avg Monthly Bonus],
    "Benefits Cost", [Avg Benefits Cost]
)
```

### 35. Other Metric (Top 10)
- Format: Decimal, 1 place  (`#,0.0`)
- Display folder: Metric switch
- Replaces Tableau: `Metrics_Other filtered by Rank_Measure <= 10`

```dax
Other Metric (Top 10) =
VAR _type = IF ( HASONEVALUE ( CategoryBridge[Category Type] ), VALUES ( CategoryBridge[Category Type] ), "Full Name" )
VAR _value = CALCULATE ( [Other Metric], CategoryBridge[Category Type] = _type )
VAR _rank =
    CALCULATE (
        RANKX ( ALLSELECTED ( CategoryBridge[Category Value] ), [Other Metric], , DESC, Skip ),
        CategoryBridge[Category Type] = _type
    )
RETURN
    IF ( NOT ISBLANK ( _value ) && _rank <= 10, _value )
```

## Home table: `CustomerMetricPicker`

### 36. Customer Metric
- Format: Decimal, 2 places  (`#,0.00`)
- Display folder: Metric switch
- Replaces Tableau: `Metrics_Customer (CASE on Customer Metrics parameter)`

```dax
Customer Metric =
SWITCH (
    SELECTEDVALUE ( CustomerMetricPicker[Metric], "Customer Complaints" ),
    "Customer Complaints", [Customer Complaints],
    "Customer Rating", [Customer Rating],
    "Customer Satisfaction", [Customer Satisfaction (KPI)]
)
```

### 37. Customer Metric (Top 10)
- Format: Decimal, 2 places  (`#,0.00`)
- Display folder: Metric switch
- Replaces Tableau: `Metrics_Customer filtered by Rank_Measure <= 10`

```dax
Customer Metric (Top 10) =
VAR _type = IF ( HASONEVALUE ( CategoryBridge[Category Type] ), VALUES ( CategoryBridge[Category Type] ), "Full Name" )
VAR _value = CALCULATE ( [Customer Metric], CategoryBridge[Category Type] = _type )
VAR _rank =
    CALCULATE (
        RANKX ( ALLSELECTED ( CategoryBridge[Category Value] ), [Customer Metric], , DESC, Skip ),
        CategoryBridge[Category Type] = _type
    )
RETURN
    IF ( NOT ISBLANK ( _value ) && _rank <= 10, _value )
```

## Home table: `SalesMetricPicker`

### 38. Sales Metric
- Format: Decimal, 1 place  (`#,0.0`)
- Display folder: Metric switch
- Replaces Tableau: `Metrics_Sales (CASE on Sales Metrics parameter)`

```dax
Sales Metric =
SWITCH (
    SELECTEDVALUE ( SalesMetricPicker[Metric], "Customer Satisfaction" ),
    "Customer Satisfaction", [Avg Customer Satisfaction],
    "On Time Delivery", AVERAGE ( BusinessOutcomes[On Time Delivery] ),
    "Nps Score", AVERAGE ( BusinessOutcomes[NPS Score] ),
    "Waste Percentage", AVERAGE ( BusinessOutcomes[Waste Percentage] )
)
```

## Home table: `RankBand`

### 39. Sales Actual (Selected Band)
- Format: Currency ($), 0 decimals  (`\$#,0`)
- Display folder: Ranking
- Replaces Tableau: `Top Stores: SUM(Sales_Actual) where Rank_filter = selected band`

```dax
Sales Actual (Selected Band) =
VAR _band = SELECTEDVALUE ( RankBand[Band], "Top 5" )
RETURN
    IF ( [Store Rank Band] = _band, [Sales Actual] )
```

### 40. Sales Metric (Selected Band)
- Format: Decimal, 1 place  (`#,0.0`)
- Display folder: Ranking
- Replaces Tableau: `Top Stores: Metrics_Sales where Rank_filter = selected band`

```dax
Sales Metric (Selected Band) =
VAR _band = SELECTEDVALUE ( RankBand[Band], "Top 5" )
RETURN
    IF ( [Store Rank Band] = _band, [Sales Metric] )
```
